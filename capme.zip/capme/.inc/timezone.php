<?php

// If you've configured Snorby to render timestamps
// in your local timezone, please set that timezone here.

// For a full list of PHP timezones, please see:
// http://php.net/manual/en/timezones.php

$timezone = 'Etc/GMT';

?>
