<?php

// DB Info
$dbHost = '127.0.0.1';
$dbName = 'securityonion_db';
$dbUser = 'readonly';
$dbPass = 'securityonion';

// Sguild Info
$sgVer  = "SGUIL-0.9.0 OPENSSL ENABLED";
$sgHost = "127.0.0.1";
$sgPort = "7734";

?>
