<?php
header("Location: /capme");
exit;
?>
