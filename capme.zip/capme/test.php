<!DOCTYPE html>
<html>
<body>
	<h1>TEST</h1>
	<?php
	function splunk_authenticate($splunk_host, $splunkd_port, $usr, $pwd) {
		$ch = curl_init();
		$url = "https://$splunk_host:$splunkd_port/services/auth/login?output_mode=json";
		$loginInfo = "username=$usr&password=$pwd";

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $loginInfo);
		curl_setopt($ch, CURLOPT_POST, 1);

		$headers = array();
		$headers[] = "Cache-Control: no-cache";
		$headers[] = "Content-Type: application/x-www-form-urlencoded";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		}

		curl_close($ch);
		//Decode the json data
		$result_object = json_decode($result, true);
		$session_key = $result_object['sessionKey'];
		// Return object
		return $session_key;
	}

	//Send the search to splunk
	function splunk_search($splunk_host, $splunkd_port, $splunk_sessionKey, $query, $usr){
		$ch = curl_init();
		$url = "https://$splunk_host:$splunkd_port/servicesNS/$usr/securityonion/search/jobs?earliest_time=-30d&output_mode=json";
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
		curl_setopt($ch, CURLOPT_POST, 1);

		$headers = array();
		$headers[] = "Authorization: Splunk $splunk_sessionKey";
		$headers[] = "Cache-Control: no-cache";
		$headers[] = "Content-Type: application/x-www-form-urlencoded";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
		    echo 'Error:' . curl_error($ch);
		}
		curl_close ($ch);
		//Decode the json data
		$result_object = json_decode($result, true);
		$searchID = $result_object['sid'];
		// Return object
		return $searchID;
	}

	function conn_search($splunk_host, $splunk_host, $splunkd_port, $splunk_sessionKey, $query, $st, $et, $usr){
		$ch = curl_init();
		$url = "https://$splunk_host:$splunkd_port/servicesNS/$usr/securityonion/search/jobs?earliest_time=$st&latest_time=$et&output_mode=json";
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
		curl_setopt($ch, CURLOPT_POST, 1);

		$headers = array();
		$headers[] = "Authorization: Splunk $splunk_sessionKey";
		$headers[] = "Cache-Control: no-cache";
		$headers[] = "Content-Type: application/x-www-form-urlencoded";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
		    echo 'Error:' . curl_error($ch);
		}
		curl_close ($ch);
		//Decode the json data
		$result_object = json_decode($result, true);
		$searchID = $result_object['sid'];
		// Return object
		return $searchID;
	}

	//Check to see if the search is done
	function splunk_check_status($splunk_host, $splunkd_port, $splunk_sessionKey, $searchID, $usr){
		do {
			$ch = curl_init();
			$url = "https://$splunk_host:$splunkd_port/servicesNS/$usr/securityonion/search/jobs/$searchID?output_mode=json";
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


			$headers = array();
			$headers[] = "Authorization: Splunk $splunk_sessionKey";
			$headers[] = "Cache-Control: no-cache";
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			$result = curl_exec($ch);
			if (curl_errno($ch)) {
			    echo 'Error:' . curl_error($ch);
			}
			$result_object = json_decode($result, true);
			$status = $result_object['entry'][0]['content']['isDone'];
			$failed = $result_object['entry'][0]['content']['isFailed'];
			if($failed == true){
				$type = $result_object['entry'][0]['content']['messages'][0]['type'];
				$text = $result_object['entry'][0]['content']['messages'][0]['text'];
				$reason =  $typ . ':' . $text;
				return "$reason";
			}

		} while( $status != true);
		
		curl_close ($ch);

		return "finished";
	}

	//Get the results back
	function splunk_get_results($splunk_host, $splunkd_port, $splunk_sessionKey, $searchID, $usr){
		$ch = curl_init();
		$url = "https://$splunk_host:$splunkd_port/servicesNS/$usr/securityonion/search/jobs/$searchID/results?output_mode=json&count=0";
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


		$headers = array();
		$headers[] = "Authorization: Splunk $splunk_sessionKey";
		$headers[] = "Cache-Control: no-cache";
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
		    echo 'Error:' . curl_error($ch);
		}
		curl_close ($ch);
		//Decode the json data
		$result_object = json_decode($result, true);
		// Return object
		$result_object = $result_object['results'];
		return $result_object;

	}

	$sp_array = file("/etc/nsm/securityonion.conf");
	
	// Define the strings we are looking for
	$splunk_host = "SPLUNK_HOST";
	$splunkd_port = "SPLUNKD_PORT";
	$usr     = $_SERVER['PHP_AUTH_USER'];
    $pwd     = $_SERVER['PHP_AUTH_PW'];

    foreach($sp_array as $line) {
		// If we find a match, retrieve only the value and clean it up
		if(strpos($line, $splunk_host) !== false) {
			list(, $new_str) = explode("=", $line);
			$rm_whitespace = trim($new_str);
			$splunk_host = trim($rm_whitespace, '"');
		}
		if(strpos($line, $splunkd_port) !== false) {
			list(, $new_str) = explode("=", $line);
			$rm_whitespace = trim($new_str);
			$splunkd_port = trim($rm_whitespace, '"');
		}
	}

	$spid = "81f17f50319592dfb1e2e6efb4910c60";
	$query = "search=search sourcetype=* spid=$spid | table *";
	$splunk_sessionKey = splunk_authenticate($splunk_host, $splunkd_port, $usr, $pwd);
	$searchID = splunk_search($splunk_host, $splunkd_port, $splunk_sessionKey, $query, $usr);
	$status = splunk_check_status($splunk_host, $splunkd_port, $splunk_sessionKey, $sid, $usr);
	if($status == "finished") {
		$search_results = splunk_get_results($splunk_host, $splunkd_port, $splunk_sessionKey, $sid, $usr);
	} else {
		"$status";
	}

	if ( ! isset($search_results) ) {
		$errMsgSplunk = "Splunk query didn't return anything.";
	} elseif ( empty($search_results)) {
		$errMsgSplunk = "Splunk query couldn't find this ID.";
	/*} elseif ( $elastic_response_object["hits"]["total"] != "1") {
		$errMsgElastic = "Initial ES query returned multiple results.";*/
	} else {

		if (isset($search_results[0]['uid'])){
			$uid = $search_results[0]["uid"];
			if (is_array($uid)) {
					$uid = $search_results[0]['uid'][0];
			}
				// A Bro CID should be alphanumeric and begin with the letter C
			if (ctype_alnum($uid)) {
				if (substr($uid,0,1)=="C") {
					$type = "bro_conn";
					$bro_query = $uid;
				}
			}
		}elseif (isset($search_results[0]['id']) ) {
			$id = $search_results[0]['id'];
			if (ctype_alnum($id)) {
		        if (substr($id,0,1)=="F") {
	                $type = "bro_files";
					$bro_query = $id;
		        }
			}
		} elseif (isset($search_results[0]['fuid']) ) {
			$uid = $search_results[0]["uid"];
			if (is_array($uid)) {
					$uid = $search_results[0]['uid'][0];
			}
				// A Bro CID should be alphanumeric and begin with the letter C
			if (ctype_alnum($uid)) {
				if (substr($uid,0,1)=="C") {
					$type = "bro_conn";
					$bro_query = $uid;
				}
			}
		}

		if (isset($search_results[0]['sid']) ) {
			$rule_sid = $search_results[0]['sid'];
			if ( $rule_sid > 0 && $rule_sid < 9999999) {
				$rule_command = "grep -h sid:$rule_sid\; /etc/nsm/rules/*.rules |head -1";
				$rule = shell_exec($rule_command);
			}
		}


		if ( $bro_query == "" ) {
			// source_ip
			if (isset($search_results[0]["src"])) {
				$sip = $search_results[0]["src"];
				if (!filter_var($sip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
					if (filter_var($sip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
						$errMsgSplunk = "Source IP is IPV6!  CapMe currently only supports IPV4.";
					} else {
						$errMsgSplunk = "Invalid source IP.";
					}
				}
			} else {
				$search_results = "Missing source IP.";
			}

			// source_port
			if (isset($search_results[0]["src_port"])) {
				$spt = $search_results[0]["src_port"];
				if (filter_var($spt, FILTER_VALIDATE_INT, array("options" => array("min_range"=>0, "max_range"=>65535))) === false) {
				        $errMsgSplunk = "Invalid source port.";
				}
			} else {
				$errMsgSplunk = "Missing source port.";
			}

			// destination_ip
			if (isset($search_results[0]["dest"])) {
				$dip = $search_results[0]["dest"];
				if (!filter_var($dip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
					if (filter_var($dip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                                                $errMsgSplunk = "Destination IP is IPV6!  CapMe currently only supports IPV4.";
                                        } else {
                                                $errMsgSplunk = "Invalid destination IP.";
                                        }
				}
			} else {
				$errMsgSplunk = "Missing destination IP.";
			}

			// destination_port
			if (isset($search_results[0]["dest_port"])) {
				$dpt = $search_results[0]["dest_port"];
				if (filter_var($dpt, FILTER_VALIDATE_INT, array("options" => array("min_range"=>0, "max_range"=>65535))) === false) {
				        $errMsgSplunk = "Invalid destination port.";
				}
			} else {
				$errMsgSplunk = "Missing destination port.";
			}

			// If all four of those fields looked OK, then build a query to send to Elasticsearch
			if ($errMsgSplunk == "") {
				$type = "bro_conn";
				$bro_query = "$sip AND $spt AND $dip AND $dpt";
			}
		}
		

		$timestamp_epoch = $search_results[0]["epochTime"];
		echo "$timestamp_epoch";
		echo "<br>";

		$mintime=time() - 50 * 365 * 24 * 60 * 60;
		$maxtime=time() + 5 * 365 * 24 * 60 * 60;
		if (filter_var($timestamp_epoch, FILTER_VALIDATE_INT, array("options" => array("min_range"=>$mintime, "max_range"=>$maxtime))) === false) {
		        $errMsgSplunk = "Invalid start time.";
		}
		// Set a start time and end time for the search to allow for a little bit of clock drift amongst different log sources
		$st = $timestamp_epoch - 1800;
		$et = $timestamp_epoch + 1800;
		
		// Now we to send those parameters back to Elastic to see if we can find a matching bro_conn log
		if ($errMsgSplunk == "") {
			
			$query = "search=search sourcetype=$type $bro_query | table epochTime, src, src_port, dest, dest_port, proto";
			$searchID = conn_search($splunk_host, $splunk_host, $splunkd_port, $splunk_sessionKey, $query, $st, $et, $usr);
			$status = splunk_check_status($splunk_host, $splunkd_port, $splunk_sessionKey, $sid, $usr);
			if($status == "finished") {
				$search_results = splunk_get_results($splunk_host, $splunkd_port, $splunk_sessionKey, $sid, $usr);
			} else {
				"$status";
			}

			// Check for common error conditions.
			if ( ! isset($search_results) ) {
				$errMsgSplunk = "Splunk query didn't return anything.";
			} elseif ( empty($search_results)) {
				$errMsgSplunk = "Splunk query couldn't find this ID.";
			/*} elseif ( $elastic_response_object["hits"]["total"] != "1") {
				$errMsgElastic = "Initial ES query returned multiple results.";*/
			} else {
				// Check to see how many hits we got back from our query
				$num_records = count($search_results);
				$delta_arr = array();

				// For each hit, we need to compare its timestamp to the timestamp of our original record (from which we pivoted).
				for ( $i =0 ; $i < $num_records; $i++) {
                    $record_ts = $search_results[$i]["epochTime"];
                    if ($timestamp_epoch > $record_ts){
                    	$delta = $timestamp_epoch - $record_ts;
					} elseif ($timestamp_epoch < $record_ts){
                        $delta = $record_ts - $timestamp_epoch;
                    } else {
						$delta = 0;
					}

                    $delta_arr[$i] = $delta;
				}
				
				// Get the key for the hit with the smallest delta
				$min_val = min($delta_arr);
				$key = array_search($min_val, $delta_arr);
				
				if ( ! isset($search_results[$key]["proto"]) ) {
					$errMsgSplunk = "Second ES query didn't return a protocol field.";
				} elseif ( !in_array($search_results[$key]["proto"], array('tcp','udp'), TRUE)) {
					$errMsgSplunk = "CapMe currently only supports TCP and UDP.";
				}
				
				// In case we didn't parse out IP addresses and ports above, let's do that now
				// source_ip
				if (isset($search_results[$key]["src"])) {
					$sip = $search_results[$key]["src"];
					if (!filter_var($sip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
						if (filter_var($sip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
                            $errMsgSplunk = "Source IP is IPV6!  CapMe currently only supports IPV4.";
                        } else {
                            $errMsgSplunk = "Invalid source IP.";
                        }
					}
				} else {
					$errMsgSplunk = "Missing source IP.";
				}

				// source_port
				if (isset($search_results[$key]["src_port"])) {
					$spt = $search_results[$key]["src_port"];
					if (filter_var($spt, FILTER_VALIDATE_INT, array("options" => array("min_range"=>0, "max_range"=>65535))) === false) {
					        $errMsgSplunk = "Invalid source port.";
					}
				} else {
					$errMsgSplunk = "Missing source port.";
				}

				// destination_ip
				if (isset($search_results[$key]["dest"])) {
					$dip = $search_results[$key]["dest"];
					if (!filter_var($dip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
						if (filter_var($dip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
							$errMsgSplunk = "Destination IP is IPV6!  CapMe currently only supports IPV4.";
						} else {
							$errMsgSplunk = "Invalid destination IP.";
						}
					}
				} else {
					$errMsgSplunk = "Missing destination IP.";
				}
	
				// destination_port
				if (isset($search_results[$key]["dest_port"])) {
					$dpt = $$search_results[$key]["dest_port"];
					if (filter_var($dpt, FILTER_VALIDATE_INT, array("options" => array("min_range"=>0, "max_range"=>65535))) === false) {
					        $errMsgSplunk = "Invalid destination port.";
					}
				} else {
					$errMsgSplunk = "Missing destination port.";
				}

				$sensor = $search_results[$key]["sensorname"];
				$st = date('Y-m-d H:i:s', $timestamp_epoch);
			} 
		}
	}

	var_dump($type);
	var_dump($bro_query);


	?>
</body>
</html>